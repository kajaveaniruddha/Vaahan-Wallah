Vaahan Wallah
		- A simulator for vehicle rental system


Vaahan Wallah is a system time based simulator for vehicle rental system made using 
OOD/P with end-to-end Cpp. 
We have used ".txt" files as our data base.
Showcasing our OOPs knowledge was our priority thus,
we have kept our terminal based GUI simple but elegant . In due course of project
we have learnt many techniques to design and animate terminal, various concepts 
related to OOP and their implementation and the most important team work in building
a project. With respect to future aspects we have added 3 types of vehicles: 
cars, buses and bikes in our simulator
to show that our program has enough potential to accomodate more types
of vehicles in upcoming time.